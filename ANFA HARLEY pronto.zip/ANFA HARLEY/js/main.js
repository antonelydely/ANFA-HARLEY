// Função para login
function verificarLogin() {
    const login = document.getElementById("login").value;
    const senha = document.getElementById("senha").value;
    const erro = document.getElementById("mensagem-erro");
  
    if (login === "motoqueirofantasma" && senha === "cortandogiro") {
      window.location.href = "home.html";
      return false;
    } else {
      erro.textContent = "Usuário ou senha incorretos.";
      return false;
    }
  }
  
  // Função para trocar entre as seções
  function mostrar(secao) {
    const secoes = document.querySelectorAll(".conteudo");
    secoes.forEach(el => el.style.display = "none");
  
    const ativa = document.getElementById(secao);
    if (ativa) ativa.style.display = "block";
  }
  